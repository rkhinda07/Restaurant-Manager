Ramneek Khinda
101099146

FILES INCLUDED

client.js  - Javascript file containing client side code
database-initializer-  Javascript file to create collection of users and orders
index.js - server side code containing main functionality
home.html- HTML file for homepage
resturants.html - HTML file to get the list of restaurants
profile.html- HTML file to view the orders placed
register.html- HTML file for registering new users
users.html- html file to view the users
package.json- contains dependencies


To compile and run:
1. Open terminal in this directory and type "npm install" to install all dependencies
2. Run Mongo Daemon in background
3. Type "node database-initializer"and hit enter to create the database
4. Type "node index.js" and hit enter to run the server
3. Open the web browser and go to url "http://localhost:3000/" which displays the homepage of restaurant
