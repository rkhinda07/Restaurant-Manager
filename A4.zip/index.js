const fs = require("fs");
// const ejs = require("ejs");
const express = require('express')
const app = express()
var bodyParser = require("body-parser");
const session = require('express-session')
const cookieParser = require('cookie-parser')

app.use(cookieParser())

app.use(session({ secret: 'QWERTYUIOPASDFGHJKL1234567890'}))

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


let mongo = require('mongodb');
let MongoClient = mongo.MongoClient;
let db;


function auth(req, res, next) {
	if(!req.session.loggedin){
		res.status(401).send("Unauthorized");
		return;
	}
	next();
};

// MongoClient.connect("mongodb://localhost:27017/", function(err, client) {
//   if(err) throw err;	

//   db = client.db('a4');
//   db.collection("users").find({}).toArray( function(err, result) {
//     if (err) throw err;
//     console.log(result);
//     // db.close();
//   });
// });

// app.get('/',)

app.get('/client.js', function (request, response,error) {
	fs.readFile("client.js", function(err, data){
		if(err){
			response.statusCode = 500;
			response.end("Error reading file.");
			return;
		}
		response.statusCode = 200;
		response.setHeader("Content-Type", "application/javascript"); 
		response.end(data);
	});
})

app.get('/orderform.js', function (request, response,error) {
	fs.readFile("public/orderform.js", function(err, data){
		if(err){
			response.statusCode = 500;
			response.end("Error reading file.");
			return;
		}
		response.statusCode = 200;
		response.setHeader("Content-Type", "application/javascript"); 
		response.end(data);
	});
})

app.get('/users' ,function (request, response,error) {
	if(request.headers.accept.split(',')[0]=="text/html"){
		fs.readFile("users.html", function(err, data){ 
			if(err){ 
				response.statusCode = 500;
				response.end("Error reading file.");
				return;
			}
			response.statusCode = 200;
			response.setHeader("Content-Type", "text/html"); 
			response.end(data);
		});
	}
	else if(request.headers.accept.split(',')[0]=="application/json"){
		MongoClient.connect("mongodb://localhost:27017/", function(err, client) {
		  if(err) throw err;	

		  db = client.db('a4');
		  db.collection("users").find({}).toArray( function(err, result) {
		    if (err){
				response.statusCode = 200;
				response.setHeader("Content-Type", "application/JSON"); 
				response.end("Failed");
		     throw err;
		 	}
		 	response.statusCode = 200;
				response.setHeader("Content-Type", "application/JSON"); 
				response.end(JSON.stringify(result));
		     
		    // db.close();
		  });
		});

	}
	return;
})

app.get('/users/:username' ,function (request, response,error) {
	let username = request.params.username; 
	let sessionUsername = request.session.username
	let data
	if(username=="client.js"){
		fs.readFile("client.js", function(err, data){
			if(err){
				response.statusCode = 500;
				response.end("Error reading file.");
				return;
			}
			response.statusCode = 200;
			response.setHeader("Content-Type", "application/javascript"); 
			response.end(data);
		});
	}
	else{
	db.collection("users").find({username: username}).toArray(function(err, result){
		if(err)throw err;
		data = result
		if(result){
			if(result.privacy&&username!=sessionUsername){
				response.statusCode = 401
				response.end('Not authorized. Invalid password.');
			}
		}
		else{
			response.statusCode = 401
			response.end('Invalid username');
		}	
		if(request.headers.accept.split(',')[0]=="text/html"){
			fs.readFile("profile.html", function(err, data){ 
				if(err){ 
					response.statusCode = 500;
					response.end("Error reading file.");
					return;
				}
				response.statusCode = 200;
				response.setHeader("Content-Type", "text/html"); 
				response.end(data);
			});
		}
		else if(request.headers.accept.split(',')[0]=="application/json"){
			MongoClient.connect("mongodb://localhost:27017/", function(err, client) {
			  if(err) throw err;	

			  db = client.db('a4');
		
			  db.collection("orders").find({username:username}).toArray( function(err, result) {
			    if (err){
					response.statusCode = 200;
					response.setHeader("Content-Type", "application/JSON"); 
					response.end("Failed");
			     throw err;
			 	}
			 	response.statusCode = 200;
				response.setHeader("Content-Type", "application/JSON"); 
				response.end(JSON.stringify(result));
			     
			    // db.close();
			  });
			});
		}
	});
	}

	return;
})

// app.get('/users/:id', function(req , res){
//   	let id= request.params.id;

// });

app.post('/login',function(req,res,error){
	if(req.session.loggedin){
		res.status(200).send("Already logged in.");
		return;
	}
	console.log(req.body.username);
	let username = req.body.username;
	let password = req.body.password;
	db.collection("users").findOne({username: username}, function(err, result){
		if(err)throw err;
		
		console.log(result);
		
		if(result){
			if(result.password === password){
				req.session.loggedin = true;
				req.session.username = username;
				req.session.id = result._id
				console.log(res.cookie)
				res.cookie('c_ux',username,{maxAge:90000000})
				res.status(200).send("Logged in");
			}else{
				res.status(401).send("Not authorized. Invalid password.");
			}
		}else{
			res.status(401).send("Not authorized. Invalid username.");
			return;
		}
	});
})

app.get("/logout",function logout(req, res, next){
	if(req.session.loggedin){
		req.session.loggedin = false;
		req.session.username = null	;
		res.status(200).send("Logged out");
	}else{
		res.status(200).send("You cannot log out because you aren't logged in.");
	}
});

app.get('/orderform', function (request, response,error) {
	fs.readFile("public/orderform.html", function(err, data){
		if(err){ 
			response.statusCode = 500;
			response.end("Error reading file.");
			return;
		}
		response.statusCode = 200;
		response.setHeader("Content-Type", "text/html"); 
		response.end(data);
	});
})

app.get('/register', function (request, response,error) {
		fs.readFile("register.html", function(err, data){ 
			if(err){ 
				response.statusCode = 500;
				response.end("Error reading file.");
				return;
			}
			response.statusCode = 200;
			response.setHeader("Content-Type", "text/html"); 
			response.end(data);
		});
	
})

app.get('/', function (request, response,error) {
		fs.readFile("home.html", function(err, data){ 
			if(err){ 
				response.statusCode = 500;
				response.end("Error reading file.");
				return;
			}
			response.statusCode = 200;
			response.setHeader("Content-Type", "text/html"); 
			response.end(data);
		});
	
})
app.post('/register',function(request,response,error){
	MongoClient.connect("mongodb://localhost:27017/", function(err, client) {
	  	if(err) throw err;	
	  	console.log(request.body)
	  	let username= request.body && request.body.username;
	  	let data
	  	db = client.db('a4');
	  	db.collection("users").find({username:username}).toArray( function(err, result) {
		    if (err){
		     throw err;
		 	}
		 	if(result){
		 		data  = result
				response.statusCode = 402;
				response.setHeader("Content-Type", "application/JSON"); 
				response.end("User Already Exists");
		 	}
		 	else{
			  	db.collection("users").insertOne(request.body, function(err, res) {
				    if (err) throw err;
				    response.statusCode = 200;
					response.setHeader("Content-Type", "application/JSON"); 
					response.end("Successful");
				})		 		
		 	}
		});
		if(data){
		}
	});
})

app.post('/orders',function(request,response,error){
	let data = request.body

	MongoClient.connect("mongodb://localhost:27017/", function(err, client) {
		if(err) throw err;	

		db = client.db('a4');
		let username = request.session.username;
		let data=request.body || {};
		data.username = username
		db.collection("orders").insertOne(request.body, function(err, res) {
		    if (err) throw err;
		    response.statusCode = 200;
			response.setHeader("Content-Type", "application/JSON"); 
			response.end("Successful");
		})
	});
})


MongoClient.connect("mongodb://localhost:27017", function(err, client) {
	if (err) {
		console.log("Error in connecting to database");
		console.log(err);
		return;
	}
	
	//Get the database and save it to a variable
	db = client.db("tokens");
	
	//Only start listening now, when we know the database is available
	app.listen(3000);
	console.log("Server listening on port 3000");
})












