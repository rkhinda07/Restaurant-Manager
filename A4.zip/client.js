function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

function Auth(){
	if(getCookie("c_ux")){
		let elements = `<span><a href= "/orderform">Order Food</a></span><span>Hello ${getCookie("c_ux")}</span><span></span> <span><a href= "/users/`+getCookie("c_ux")+`">Click here to view your profile</a></span> <span onclick="logout()">Logout</span>`
		document.getElementById("pageHeader").innerHTML = document.getElementById("pageHeader").innerHTML +  elements
	}
	else{
		document.getElementById("pageHeader").innerHTML = document.getElementById("pageHeader").innerHTML + `<span><a href= "/register">Register</a></span><br/> <span>
				<input type="text" id="username" />
				<input type="password" id="password" />
				<button onclick="loginUser()"> Submit</button>
			</span>	`
	}
}

function initUsers(){
	let req = new XMLHttpRequest(); 
	req.onreadystatechange = function (){ 
		if(this.readyState == 4 && this.status  == 200){
			data = JSON.parse(req.responseText); 
			document.getElementById("usersList").innerHTML = createUsersList(data||[]); 
		}
	}
	req.open("GET", "/users", false);
	req.setRequestHeader("accept", "application/json" );
	req.send();	
}

function createUsersList(users){
 	let result = "";
 	users.map(elem => {
		result += `<div><a href="users/${elem.username}">${elem.username}</a></div>`
	});
 	return result;
}

function registerUser(){
	let data = {}
	data.username = document.getElementById("username").value
	data.password = document.getElementById("password").value

	console.log("!!!!!!!!!!!!!11",data.username,data.password)
	if(data.username&& data.password){
		let req = new XMLHttpRequest(); 
		req.open("POST", "/register");

		req.setRequestHeader('Content-type', 'application/json');
		req.onreadystatechange = function (){ 
			if(this.readyState == 4 && this.status  == 200){
				console.log("!!!!!!!111",this.response)
				// let data = JSON.parse(this.response)
				// window.location.href = "resturants/" + data.id
			}
		}
		req.send(JSON.stringify(data));
	}
	else{
		alert("Enter Complete Details")
	}
}

function loginUser(){
	let data = {}
	data.username = document.getElementById("username").value
	data.password = document.getElementById("password").value

	if(data.username&& data.password){
		let req = new XMLHttpRequest(); 
		req.open("POST", "/login");

		req.setRequestHeader('Content-type', 'application/json');
		req.onreadystatechange = function (){ 
			if(this.readyState == 4 && this.status  == 200){
				console.log("!!!!!!!111",this.response,this.response.headers)
				// let data = JSON.parse(this.response)
				// window.location.href = "resturants/" + data.id
				location.reload()
			}
		}
		req.send(JSON.stringify(data));
	}
	else{
		alert("Enter Complete Details")
	}
}

function initOrders(){
	let link = "/users/"+ window.location.href.split('/')[4];
	let req = new XMLHttpRequest(); 
	req.onreadystatechange = function (){ 
		if(this.readyState == 4 && this.status  == 200){
			data = JSON.parse(req.responseText); 
			document.getElementById("orderList").innerHTML = createOrderList(data||[]); 
		}
	}
	req.open("GET", link , false);
	req.setRequestHeader("accept", "application/json" );
	req.send();	
}

function createOrderList(orders){
 	let result = "";
 	orders.map(elem => {
		result += `<div><a href="user/${elem._id}">${elem._id}</a></div>`
	});
 	return result;
}

function logout(){
	let req = new XMLHttpRequest(); 

	req.onreadystatechange = function (){ 
		if(this.readyState == 4 && this.status  == 200){
			document.cookie = "";
			location.reload(); 
		}
	}
	req.open("GET", "/logout" , false);
	req.setRequestHeader("accept", "application/json" );
	req.send();	
}